rootProject.name = "community-service"
