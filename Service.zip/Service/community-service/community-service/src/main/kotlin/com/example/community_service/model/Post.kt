package com.example.community_service.model

import jakarta.persistence.*
import java.time.LocalDateTime

@Entity
@Table(name = "post")
data class Post(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "post_id")
    val postId: Long? = null, // 게시글 번호 (자동 증가)

    @Column(name = "user_id", nullable = false, length = 100)
    val userId: String, // 아이디 (작성자)

    @Column(name = "title", nullable = false, length = 100)
    val title: String, // 제목

    @Column(name = "content", nullable = false, columnDefinition = "TEXT")
    val content: String, // 내용

    @Column(name = "created_at", nullable = false, updatable = false)
    val createdAt: LocalDateTime = LocalDateTime.now() // 생성 날짜
)
