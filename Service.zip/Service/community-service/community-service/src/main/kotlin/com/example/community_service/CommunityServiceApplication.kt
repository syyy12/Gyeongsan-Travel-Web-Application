package com.example.community_service

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class CommunityServiceApplication

fun main(args: Array<String>) {
	runApplication<CommunityServiceApplication>(*args)
}
