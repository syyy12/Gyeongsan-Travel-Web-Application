package com.example.community_service.service


import com.example.community_service.model.Post
import com.example.community_service.repository.PostRepository
import org.springframework.stereotype.Service

@Service
class PostService(private val postRepository: PostRepository) {

    // 📌 모든 게시글 조회
    fun getAllPosts(): List<Post> = postRepository.findAll()

    // ✅ 새 글 저장
    fun createPost(post: Post): Post {
        return postRepository.save(post)
    }

    // 🔥 특정 게시글 조회 (추가)
    fun getPostById(postId: Long): Post {
        return postRepository.findById(postId).orElseThrow { RuntimeException("게시글을 찾을 수 없습니다.") }
    }
}
