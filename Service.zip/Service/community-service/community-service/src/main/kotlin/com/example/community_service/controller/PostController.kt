package com.example.community_service.controller

import com.example.community_service.model.Post
import com.example.community_service.service.PostService
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import org.springframework.ui.Model
import org.springframework.stereotype.Controller


@Controller
@RequestMapping("/community")
class PostController(private val postService: PostService)
 {

    @GetMapping("/main")
    fun communityMain(model: Model): String {
        return "main"  // `main.html` 페이지 반환
    }
     // ✅ 글쓰기 페이지 반환
     @GetMapping("/write")
     fun showWritePage(@RequestParam("id", required = false) userId: String?, model: Model): String {
         model.addAttribute("userId", userId)
         return "write"  // 📌 write.html을 반환 (Thymeleaf 템플릿)
     }

     @GetMapping
     @ResponseBody
     fun getAllPosts(): ResponseEntity<List<Post>> {
         val posts = postService.getAllPosts()
         return ResponseEntity.ok(posts)
     }

     // ✅ 특정 게시글 상세 페이지 (HTML 반환)
     @GetMapping("/{postId}")
     fun getPostPage(@PathVariable postId: Long, @RequestParam id: String, model: Model): String {
         model.addAttribute("postId", postId)
         model.addAttribute("userId", id)
         return "post"  // `post.html` 렌더링
     }

     // ✅ 특정 게시글 조회 API (JSON 반환)
     @GetMapping("/{postId}/data")
     @ResponseBody
     fun getPostData(@PathVariable postId: Long): ResponseEntity<Post> {
         return ResponseEntity.ok(postService.getPostById(postId))
     }

     // ✅ 새 글 작성 API (POST 요청)
     @PostMapping("/post")
     fun createPost(@RequestBody post: Post): ResponseEntity<Post> {
         return ResponseEntity.ok(postService.createPost(post))
     }
}
