package com.example.user_service.controller

import com.example.user_service.model.User
import com.example.user_service.repository.UserRepository
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Controller
import org.springframework.ui.Model
import org.springframework.web.bind.annotation.*

@Controller
@RequestMapping("/users")
class UserController(private val userRepository: UserRepository,
                     @Value("\${GATEWAY_URL:http://gyetrip.iptime.org:8080}") // GATEWAY_URL:http://localhost:8080
                     private val gatewayUrl: String                           // GATEWAY_URL: http://gyetrip.iptime.org:8080
) {

    // 로그인 페이지
    @GetMapping("/login")
    fun loginPage(): String {
        return "login"
    }

    // 로그인 처리
    @PostMapping("/login")
    fun login(@RequestParam id: String, @RequestParam password: String, model: Model): String {
        val user = userRepository.findById(id).orElse(null)
        return if (user != null && user.password == password) {
            "redirect:$gatewayUrl/?id=$id"  // 로그인 성공 후 메인 페이지로 이동
        } else {
            model.addAttribute("error", "아이디 또는 비밀번호가 잘못되었습니다.")
            "login"
        }
    }

    // 회원가입 페이지
    @GetMapping("/register")
    fun registerPage(): String {
        return "register"
    }

    @PostMapping("/register")
    fun register(
        @RequestParam id: String,
        @RequestParam username: String,
        @RequestParam password: String,
        @RequestParam phoneNum: String?,
        @RequestParam nickname: String?,
        model: Model
    ): String {
        // 1. 중복 체크
        if (userRepository.existsByUsername(username)) {
            model.addAttribute("error", "이미 사용 중인 아이디입니다.")
            return "register"  // 회원가입 폼 페이지로 다시 이동 (register.html)
        }

        // 2. 저장
        val newUser = User(id, username, password, phoneNum, nickname)
        userRepository.save(newUser)

        // 3. 로그인 페이지로 리다이렉트
        return "redirect:$gatewayUrl/users/login"

    }

}
