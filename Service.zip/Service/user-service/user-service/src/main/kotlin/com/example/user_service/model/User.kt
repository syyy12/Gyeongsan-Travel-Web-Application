package com.example.user_service.model

import jakarta.persistence.*

@Entity
@Table(name = "users")
data class User(
    @Id
    val id: String,  // 회원 ID

    @Column(nullable = false)
    val username: String,  // 이름

    @Column(nullable = false)
    val password: String,  // 비밀번호

    val phoneNum: String? = null,  // 전화번호
    val nickname: String? = null  // 닉네임
)
