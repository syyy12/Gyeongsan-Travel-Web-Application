document.addEventListener("DOMContentLoaded", function () {
    let currentIndex = 0;
    const slides = document.querySelectorAll(".slide");
    const slider = document.querySelector(".slider");

    function showSlide(index) {
        slider.style.transform = `translateX(-${index * 100}%)`;
    }

    function prevSlide() {
        currentIndex = (currentIndex > 0) ? currentIndex - 1 : slides.length - 1;
        showSlide(currentIndex);
    }

    function nextSlide() {
        currentIndex = (currentIndex < slides.length - 1) ? currentIndex + 1 : 0;
        showSlide(currentIndex);
    }

    // 자동 슬라이드 (4초마다)
    setInterval(nextSlide, 4000);

    // ✅ 로그인 상태 확인
    const userId = document.getElementById("login-info").getAttribute("data-user-id");

    // ✅ 여행지들 & 커뮤니티 접근 제한
    function restrictAccess(event) {
        if (!userId) {
            event.preventDefault();
            alert("로그인이 필요합니다!");
        }
    }

     document.getElementById("travel-link").addEventListener("click", function(event) {
            restrictAccess(event, "/travel/main");
        });

        document.getElementById("community-link").addEventListener("click", function(event) {
            restrictAccess(event, `/community/main?id=${userId}`);
        });
});
