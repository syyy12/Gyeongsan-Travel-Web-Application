package com.example.api_gateway.controller

import org.springframework.stereotype.Controller
import org.springframework.ui.Model
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RequestParam

@Controller
class IndexController {

    @GetMapping("/")
    fun mainPage(@RequestParam(required = false) id: String?, model: Model): String {
        model.addAttribute("userId", id) // URL에 있는 ID 그대로 넘김
        return "index"
    }
}
