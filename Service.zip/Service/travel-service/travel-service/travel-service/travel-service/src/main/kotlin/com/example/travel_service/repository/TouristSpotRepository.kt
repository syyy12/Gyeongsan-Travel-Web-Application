package com.example.travel_service.repository

import com.example.travel_service.model.TouristSpot
import org.springframework.data.jpa.repository.JpaRepository

interface TouristSpotRepository : JpaRepository<TouristSpot, Int>
