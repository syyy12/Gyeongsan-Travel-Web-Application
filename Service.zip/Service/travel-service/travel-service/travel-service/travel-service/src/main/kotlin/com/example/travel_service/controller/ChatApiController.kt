package com.example.travel_service.controller

import org.springframework.web.bind.annotation.*
import org.springframework.web.client.RestTemplate

@RestController
@RequestMapping("/api")
class ChatApiController {

    val restTemplate = RestTemplate()

    data class ChatRequest(val message: String)
    data class ChatResponse(val reply: String)

    @PostMapping("/chat")
    fun chat(@RequestBody request: ChatRequest): ChatResponse {
        val flaskUrl = "http://gyetrip.iptime.org:5000/ask"
        // Flask 서버 주소
        return restTemplate.postForObject(flaskUrl, request, ChatResponse::class.java)
            ?: ChatResponse("챗봇 서버 응답 실패!")
    }
}
