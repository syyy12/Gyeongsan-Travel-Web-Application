package com.example.travel_service.model

import jakarta.persistence.*

@Entity
@Table(name = "tourist_spot")
data class TouristSpot(
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    val id: Int = 0,
    val name: String = "",  // ← 기본값 추가
    val description: String? = null,
    val location: String? = null,
    val detailInfo: String? = null
)
