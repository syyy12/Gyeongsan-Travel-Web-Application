package com.example.travel_service.controller

import org.springframework.stereotype.Controller
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RequestMapping
import com.example.travel_service.repository.TouristSpotRepository
import org.springframework.ui.Model
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.RequestParam

@Controller
@RequestMapping("/travel")
class TravelController(private val repository: TouristSpotRepository) {


    @GetMapping("/main")
    fun travelMain(@RequestParam(required = false) id: String?, model: Model): String {
        val spots = repository.findAll()
        model.addAttribute("spots", spots)
        model.addAttribute("userId", id) // 🔁 HTML에서 다시 사용할 수 있도록
        return "tourist_list" // templates/tourist_list.html
    }


    @GetMapping("/detail/{id}")
    fun travelDetail(@PathVariable id: Int, @RequestParam("id") userId: String, model: Model): String {
        val spot = repository.findById(id).orElseThrow()  // 여기 변수명을 수정
        model.addAttribute("spot", spot)
        model.addAttribute("userId", userId)
        return "tourist_detail"
    }

}
