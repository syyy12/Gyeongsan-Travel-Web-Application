-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: user_db
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tourist_spot`
--

DROP TABLE IF EXISTS `tourist_spot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tourist_spot` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `detail_info` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tourist_spot`
--

LOCK TABLES `tourist_spot` WRITE;
/*!40000 ALTER TABLE `tourist_spot` DISABLE KEYS */;
INSERT INTO `tourist_spot` VALUES (1,'팔공산','경치가 뛰어난 산','경산시 남산면','가을 단풍이 아름답고 등산로가 잘 정비되어 있음'),(2,'경산 압량복합문화센터','다양한 문화행사가 열리는 복합공간','경산시 압량읍','전시회, 체험행사, 주민 참여 프로그램 등'),(3,'경산 자인 계정숲','도심 속 힐링 산책 공간','경산시 자인면','천연기념물로 지정된 숲길이 있으며 피톤치드가 가득한 장소'),(4,'경산 하양 목재문화체험장','아이들과 함께 즐길 수 있는 목공 체험공간','경산시 하양읍','목공예, DIY, 자연 놀이체험 프로그램 운영'),(5,'경산 갓바위','소원을 이루어주는 관음상','경산시 와촌면','새벽에 올라가면 소원이 이뤄진다고 알려진 불교 성지'),(6,'반곡지','벚꽃 명소이자 드라마 촬영지','경산시 와촌면','수령 100년 넘는 왕버들, 벚꽃 명소로 유명함'),(7,'삼성현 역사문화공원','역사적 인물 3인을 기리는 문화공간','경산시 남산면','원효·설총·일연을 기리는 전시 및 체험 공간'),(8,'영남대학교 러브로드','벚꽃길 산책로','경산시 대학로','봄철 데이트 및 산책 명소'),(9,'영남대 중앙도서관','근대적 건축미가 뛰어난 대형 도서관','경산시 대학로','야경 명소로 SNS에서 인기 있음'),(10,'남매근린공원','조용한 산책과 운동 공간','경산시 남산면','가벼운 등산과 야외 운동 장소'),(11,'경산 압량시장','전통과 현대가 공존하는 재래시장','경산시 압량읍','경산 대표 시장, 먹거리 다양함'),(12,'하양꿈바우시장','로컬 특산물과 간식거리 풍부','경산시 하양읍','시장 먹방 코스로 인기'),(13,'영남대 박물관','고고학 중심 대학박물관','경산시 대학로','선사시대부터 삼국시대 유물 전시'),(14,'경산 진량 카페거리','트렌디한 감성 카페 거리','경산시 진량읍','SNS 인기 카페 밀집 지역'),(15,'장산계곡','자연 속 계곡 힐링지','경산시 남산면','여름철 피서지로 인기 있는 계곡 명소');
/*!40000 ALTER TABLE `tourist_spot` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-12 21:24:37
